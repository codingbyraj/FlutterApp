# Changelog

See all changes at: https://github.com/spritewidget/spritewidget
